﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaKiBeleza
{
    /// <summary>
    /// Lógica interna para FrmCadastroAgenda.xaml
    /// </summary>
    public partial class FrmCadastroAgenda : Window
    {
        string data, paciente, especialista, especialidade, horario, tipoagenda;
        public FrmCadastroAgenda()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            FrmMenu frm = new FrmMenu();
            frm.Show();
            this.Close();
        }

        private void CldCalendario_SelectedDatesChanged(object sender, SelectionChangedEventArgs e)
        {
            LblDataAbreviada.Content = String.Format("{0:dd/MM/yyyy}", CldCalendario.SelectedDate);
            LblDiaSemana.Content = String.Format("{0:dddd}", CldCalendario.SelectedDate);
        }

        private void FrmCadAgenda_Loaded(object sender, RoutedEventArgs e)
        {
            LblDataAbreviada.Content = string.Format("{0:dd/MM/yyyy}", DateTime.Now);
            LblDiaSemana.Content = string.Format("{0:dddd}", DateTime.Now);

            MySqlConnection cn = new MySqlConnection();
            cn.ConnectionString = "SERVER = localhost; USER = root; DATABASE = kibeleza";
            cn.Open();

            //Tabela especialidade
            string selecionar = "SELECT especialidade FROM especialidade";

            MySqlCommand com = new MySqlCommand(selecionar, cn);

            MySqlDataAdapter da = new MySqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            CmbEspecialidade.DisplayMemberPath = "especialidade";
            CmbEspecialidade.ItemsSource = dt.DefaultView;

            //Tabela paciente/cliente

            string selecionar1 = "SELECT nome FROM cliente";

            MySqlCommand com1 = new MySqlCommand(selecionar1, cn);

            MySqlDataAdapter da1 = new MySqlDataAdapter(com1);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            CmbPaciente.DisplayMemberPath = "nome";
            CmbPaciente.ItemsSource = dt1.DefaultView;

            //tabela especialista

            string selecionar2 = "SELECT nome FROM especialista";

            MySqlCommand com2 = new MySqlCommand(selecionar2, cn);

            MySqlDataAdapter da2 = new MySqlDataAdapter(com2);
            DataTable dt2 = new DataTable();
            da2.Fill(dt2);
            CmbEspecialista.DisplayMemberPath = "nome";
            CmbEspecialista.ItemsSource = dt2.DefaultView;
        }

        private void RadConsulta_Checked(object sender, RoutedEventArgs e)
        {
            tipoagenda = "C";
            BtnSalvar.IsEnabled = true;
        }

        private void RadEncaixe_Checked(object sender, RoutedEventArgs e)
        {
            tipoagenda = "E";
            BtnSalvar.IsEnabled = true;
        }

        private void BtnLimpar_Click(object sender, RoutedEventArgs e)
        {
            CmbPaciente.Text = "";
            CmbEspecialista.Text = "";
            CmbEspecialidade.Text = "";
            CmbHorario.Text = "";
            RadConsulta.IsChecked = false;
            RadEncaixe.IsChecked = false;

            data = null;
            paciente = null;
            especialidade = null;
            especialista = null;
            horario = null;
            tipoagenda = null;

            CldCalendario.SelectedDate = DateTime.Now;

            BtnSalvar.IsEnabled = false;
            RadConsulta.IsEnabled = false;
            RadEncaixe.IsEnabled = false;
        }

        private void BtnSalvar_Click(object sender, RoutedEventArgs e)
        {
            data = LblDataAbreviada.Content.ToString();
            paciente = CmbPaciente.Text;
            especialista = CmbEspecialista.Text;
            especialidade = CmbEspecialidade.Text;
            horario = CmbHorario.Text;
            modelos mo = new modelos();
            cone db = new cone();
            mo.DataAgenda = data;
            mo.Paciente = paciente;
            mo.Especialista = especialista;
            mo.Especialidade = especialidade;
            mo.HoraAgenda = horario;
            mo.TipoAgenda = tipoagenda;
            db.cadagenda(mo);

            MessageBox.Show("Agendamento realizado com sucesso!");
            CmbPaciente.Text = "";
            CmbEspecialista.Text = "";
            CmbEspecialidade.Text = "";
            CmbHorario.Text = "";
            RadConsulta.IsChecked = false;
            RadEncaixe.IsChecked = false;


            data = null;
            paciente = null;
            especialidade = null;
            especialista = null;
            horario = null;
            tipoagenda = null;

            CldCalendario.SelectedDate = DateTime.Now;

            BtnSalvar.IsEnabled = false;
            RadConsulta.IsEnabled = false;
            RadEncaixe.IsEnabled = false;
        }

        private void CmbPaciente_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            CmbEspecialista.Focus();
        }

        private void CmbEspecialista_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            CmbEspecialidade.Focus();
        }

        private void CmbEspecialidade_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            CmbHorario.Focus();
        }

        private void CmbHorario_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RadConsulta.IsEnabled = true;
            RadEncaixe.IsEnabled = true;
            BtnSalvar.Focus();
        }
    }
    
}
