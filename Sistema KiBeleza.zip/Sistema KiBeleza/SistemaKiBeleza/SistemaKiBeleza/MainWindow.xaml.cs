﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading; //Coleção ProgressBar

namespace SistemaKiBeleza
{
    /// <summary>
    /// Interação lógica para MainWindow.xam
    /// </summary>
    public partial class MainWindow : Window
    {
        int i = 0;
        string usuario, senha;
        public MainWindow()
        {
            InitializeComponent();
            TxtUsuario.Focus();
        }

        private void BtnSair_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void TxtUsuario_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                usuario = TxtUsuario.Text;
                PwbSenha.IsEnabled = true;
                PwbSenha.Focus();
            }
        }

        private void PwbSenha_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key == Key.Enter)
            {
                senha = PwbSenha.Password;
                BtnEntrar.IsEnabled = true;
                BtnEntrar.Focus();
            }
        }

        private void TxtUsuario_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void PgbLogin_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

        }

        private void BtnEntrar_Click(object sender, RoutedEventArgs e)
        {
            Thread.Sleep(1000);
            TxbProgresso.Text = "Em Progresso...";
            PgbLogin.Value = 0;
            i = 0;
            Task.Run(() =>
            {
                while (i < 100) 
                {
                    i++;
                    Thread.Sleep(50);
                    this.Dispatcher.Invoke(() => //Usar para atualização
                    {
                        PgbLogin.Value = i;
                        TxbCarregamento.Text = i + "%";
                        TxbProgresso.Text = " " + TxbProgresso.Text;
                        while (i == 100)
                        {
                            if (usuario == "ADMINISTRADOR" && senha == "1234")
                            {
                                Hide();
                                FrmMenu frm = new FrmMenu();
                                frm.Show();
                                break;
                            }
                            else if (usuario == "RECEPCIONISTA" && senha == "5678")
                            {
                                Hide();
                                FrmMenu frm = new FrmMenu();
                                frm.Show();
                                frm.BtnCadastro.IsEnabled = false;
                                frm.BtnRelatorio.IsEnabled = false;
                                break;
                            }
                            else
                            {
                                MessageBox.Show("Favor preencher o usuario ou a senha corretamente");
                                TxtUsuario.Clear();
                                PwbSenha.Clear();
                                TxtUsuario.Focus();
                                PgbLogin.Value = 0;
                                PwbSenha.IsEnabled = false;
                                BtnEntrar.IsEnabled = false;
                                TxbCarregamento.Text = "0%";
                                TxbProgresso.Text = "Bem Vindo!";
                            }
                            break;
                        }
                    });
                }
            });
        }
    }
}
