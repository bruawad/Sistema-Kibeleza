﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaKiBeleza
{
    /// <summary>
    /// Lógica interna para FrmCadProduto.xaml
    /// </summary>
    public partial class FrmCadProduto : Window
    {
        string nome, tipo, marca, grupo, subgrupo, local;
        double valorCompra, lucro, valorVenda, qtde;
        int codigo;

        private void TxtTipoProduto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtTipoProduto.Text != "")
                {
                    tipo = TxtTipoProduto.Text; //Variável nome recebe o conteúdo da caixa de texto
                    LblNomeProduto.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtMarca.IsEnabled = true;
                    TxtMarca.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblTipoProduto.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
                
        }

        private void TxtMarca_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtMarca.Text != "")
                {
                    marca = TxtMarca.Text; //Variável nome recebe o conteúdo da caixa de texto
                    LblMarca.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtGrupo.IsEnabled = true;
                    TxtGrupo.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblMarca.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
                
        }

        private void TxtQuantidade_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtQuantidade.Text != "")
                {
                    qtde = double.Parse(TxtQuantidade.Text); //Variável nome recebe o conteúdo da caixa de texto
                    LblQuantidade.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    BtnSalvar.IsEnabled = true;
                    BtnSalvar.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblQuantidade.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void BtnNovo_Click(object sender, RoutedEventArgs e)
        {
            TxtNomeProduto.IsEnabled = true;
            TxtNomeProduto.Focus();

            BtnNovo.IsEnabled = false;
            BtnLimpar.IsEnabled = true;
        }

        private void BtnLimpar_Click(object sender, RoutedEventArgs e)
        {
            TxtNomeProduto.Text = "";
            TxtTipoProduto.Text = "";
            TxtMarca.Text = "";
            TxtGrupo.Text = "";
            TxtSubGrupo.Text = "";
            TxtValorCompra.Text = "";
            TxtLucro.Text = "";
            TxtValorVenda.Text = "";
            TxtLocalizacao.Text = "";
            TxtQuantidade.Text = "";

            nome = null;
            tipo = null;
            marca = null;
            grupo = null;
            subgrupo = null;
            valorCompra = 0;
            lucro = 0;
            valorVenda = 0;
            local = null;
            qtde = 0;

            TxtNomeProduto.IsEnabled = false;
            TxtTipoProduto.IsEnabled = false;
            TxtMarca.IsEnabled = false;
            TxtGrupo.IsEnabled = false;
            TxtSubGrupo.IsEnabled = false;
            TxtValorCompra.IsEnabled = false;
            TxtLucro.IsEnabled = false;
            TxtLocalizacao.IsEnabled = false;
            TxtQuantidade.IsEnabled = false;

            BtnLimpar.IsEnabled = false;
            BtnSalvar.IsEnabled = false;
            BtnNovo.IsEnabled = true;
        }

        private void BtnSalvar_Click(object sender, RoutedEventArgs e)
        {
            modelos mo = new modelos();
            cone db = new cone();

            mo.Produto = nome;
            mo.TipoProduto = tipo;
            mo.Marca = marca;
            mo.Grupo = grupo;
            mo.SubGrupo = subgrupo;
            mo.ValorCompra = valorCompra;
            mo.Lucro = lucro;
            mo.ValorVenda = valorVenda;
            mo.Localizacao = local;
            mo.QtdeEstoque = qtde;

            db.cadproduto(mo);

            MessageBox.Show("produto cadastrado com sucesso!");

            TxtNomeProduto.Text = "";
            TxtTipoProduto.Text = "";
            TxtMarca.Text = "";
            TxtGrupo.Text = "";
            TxtSubGrupo.Text = "";
            TxtValorCompra.Text = "";
            TxtLucro.Text = "";
            TxtValorVenda.Text = "";
            TxtLocalizacao.Text = "";
            TxtQuantidade.Text = "";

            nome = null;
            tipo = null;
            marca = null;
            grupo = null;
            subgrupo = null;
            valorCompra = 0;
            lucro = 0;
            valorVenda = 0;
            local = null;
            qtde = 0;

            TxtNomeProduto.IsEnabled = false;
            TxtTipoProduto.IsEnabled = false;
            TxtMarca.IsEnabled = false;
            TxtGrupo.IsEnabled = false;
            TxtSubGrupo.IsEnabled = false;
            TxtValorCompra.IsEnabled = false;
            TxtLucro.IsEnabled = false;
            TxtLocalizacao.IsEnabled = false;
            TxtQuantidade.IsEnabled = false;

            BtnLimpar.IsEnabled = false;
            BtnSalvar.IsEnabled = false;
            BtnNovo.IsEnabled = true;
        }


        private void TxtGrupo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtGrupo.Text != "")
                {
                    grupo = TxtGrupo.Text; //Variável nome recebe o conteúdo da caixa de texto
                    LblGrupo.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtSubGrupo.IsEnabled = true;
                    TxtSubGrupo.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblGrupo.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
                
        }

        private void TxtSubGrupo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtSubGrupo.Text != "")
                {
                    subgrupo = TxtSubGrupo.Text; //Variável nome recebe o conteúdo da caixa de texto
                    LblSubGrupo.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtValorCompra.IsEnabled = true;
                    TxtValorCompra.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblSubGrupo.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
                
        }

        private void TxtValorCompra_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtValorCompra.Text != "")
                {
                    valorCompra = double.Parse(TxtValorCompra.Text); //Variável nome recebe o conteúdo da caixa de texto
                    TxtValorCompra.Text = "R$ " + valorCompra.ToString("N2");
                    LblValorCompra.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtLucro.IsEnabled = true;
                    TxtLucro.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblValorCompra.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
                
        }

        private void TxtLucro_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtLucro.Text != "")
                {
                    lucro = double.Parse(TxtLucro.Text); //Variável nome recebe o conteúdo da caixa de texto
                    TxtLucro.Text = lucro.ToString("N2") + "%";
                    LblLucro.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtLocalizacao.IsEnabled = true;
                    TxtLocalizacao.Focus(); //Focar na próxima txtbox

                    valorVenda = valorCompra + (valorCompra * lucro / 100);
                    TxtValorVenda.Text = "R$ " + valorVenda.ToString("N2");
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblLucro.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtLocalizacao_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtLocalizacao.Text != "")
                {
                    local = TxtLocalizacao.Text; //Variável nome recebe o conteúdo da caixa de texto
                    LblLocalizacao.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtQuantidade.IsEnabled = true;
                    TxtQuantidade.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblLocalizacao.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        

        private void TxtNomeProduto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtNomeProduto.Text != "")
                {
                    nome = TxtNomeProduto.Text; //Variável nome recebe o conteúdo da caixa de texto
                    LblNomeProduto.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtTipoProduto.IsEnabled = true;
                    TxtTipoProduto.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblNomeProduto.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        
        public FrmCadProduto()
        {
            InitializeComponent();
        }

        private void BtnSair_Click(object sender, RoutedEventArgs e)
        {
            FrmMenu frm = new FrmMenu();
            frm.Show();
            this.Close();
        }
    }
}
