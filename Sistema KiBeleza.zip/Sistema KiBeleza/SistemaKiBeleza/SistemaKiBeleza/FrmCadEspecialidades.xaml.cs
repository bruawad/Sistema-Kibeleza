﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaKiBeleza
{
    /// <summary>
    /// Lógica interna para FrmCadEspecialidades.xaml
    /// </summary>
    public partial class FrmCadEspecialidades : Window
    {
        string especialidade;
        int codigo;
        public FrmCadEspecialidades()
        {
            InitializeComponent();
        }

        private void BtnSair_Click(object sender, RoutedEventArgs e)
        {
            FrmMenu frm = new FrmMenu();
            frm.Show();
            this.Close();
        }

        private void TxtCodigo_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void TxtEspecialidade_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtEspecialidade.Text != "")
                {
                    especialidade = TxtEspecialidade.Text; //Variável nome recebe o conteúdo da caixa de texto
                    LblEspecialidade.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    BtnSalvar.IsEnabled = true;
                    BtnSalvar.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblEspecialidade.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void BtnNovo_Click(object sender, RoutedEventArgs e)
        {
            TxtEspecialidade.IsEnabled = true;
            TxtEspecialidade.Focus();

            BtnNovo.IsEnabled = false;
            BtnLimpar.IsEnabled = true;
        }

        private void BtnLimpar_Click(object sender, RoutedEventArgs e)
        {
            TxtEspecialidade.Text = "";

            TxtEspecialidade.IsEnabled = false;

            especialidade = null;

            BtnSalvar.IsEnabled = false;
            BtnLimpar.IsEnabled = false;
            BtnNovo.IsEnabled = true;
            BtnNovo.Focus();
        }

        private void BtnSalvar_Click(object sender, RoutedEventArgs e)
        {
            modelos mo = new modelos();
            cone db = new cone();

            mo.Especialidade = especialidade;

            db.cadespecialidade(mo);

            MessageBox.Show("Especialidade cadastrada com sucesso!");

            TxtEspecialidade.Text = "";

            BtnSalvar.IsEnabled = false;
            BtnLimpar.IsEnabled = false;
            BtnNovo.IsEnabled = true;
            BtnNovo.Focus();
        }
    }
}
