﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaKiBeleza
{
    /// <summary>
    /// Lógica interna para FrmRelatorioAgenda.xaml
    /// </summary>
    public partial class FrmRelatorioAgenda : Window
    {
        public FrmRelatorioAgenda()
        {
            InitializeComponent();
        }

        private void FrmRelAgenda_Loaded(object sender, RoutedEventArgs e)
        {
            MySqlConnection cn = new MySqlConnection();
            cn.ConnectionString = "SERVER=localhost;USER=root;DATABASE=kibeleza";
            cn.Open();

            string selecionar = "SELECT codigo,data,horario,tipoagenda," +
                "paciente,especialista,especialidade FROM agenda " +
                "ORDER BY data,horarioespecialista";
            MySqlCommand com = new MySqlCommand(selecionar, cn);
            MySqlDataAdapter da = new MySqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DtgAgenda.ItemsSource = dt.DefaultView;
        }

        private void DtpData_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            MySqlConnection cn = new MySqlConnection();
            cn.ConnectionString = "SERVER=localhost;USER=root;DATABASE=kibeleza";
            cn.Open();

            string selecionar = "SELECT codigo,data,horario, " +
                "tipoagenda,paciente,especialista,especialidade " +
                "FROM agenda WHERE data = ? ORDER BY data " + 
                "horario,especialista";

            MySqlCommand com = new MySqlCommand(selecionar, cn);
            com.Parameters.Clear();
            com.Parameters.Add("@data", MySqlDbType.String).Value = DtpData.Text;
            MySqlDataAdapter da = new MySqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DtgAgenda.ItemsSource = dt.DefaultView;
        }
    }
}
