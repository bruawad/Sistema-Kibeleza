﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaKiBeleza
{
    /// <summary>
    /// Lógica interna para FrmConEspecialista.xaml
    /// </summary>
    public partial class FrmConEspecialista : Window
    {
        string dataInicio, dataTermino, nome, endereco, complemento, bairro, cidade, uf, cep, telefone, celular, email, especialidade, diasdasemana, diasemana, segunda, terca, quarta, quinta, sexta, sabado;
        int numero, codigo;

        private void BtnExcluir_Click(object sender, RoutedEventArgs e)
        {
            codigo = int.Parse(TxtCodigo.Text);

            MySqlConnection conn = new MySqlConnection("SERVER=localhost;USER=root;DATABASE=kibeleza");
            conn.Open();
            MySqlCommand comm = new MySqlCommand("DELETE FROM especialista WHERE codigo = ?", conn);
            comm.Parameters.Clear();

            comm.Parameters.Add("codigo", MySqlDbType.Int32).Value = codigo;
            comm.ExecuteNonQuery();

            MessageBox.Show("Exclusão realizada com sucesso!");

            string selecionar = "SELECT * FROM especialista";

            MySqlCommand com = new MySqlCommand(selecionar, conn);
            MySqlDataAdapter da = new MySqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            CmbEspecialista.DisplayMemberPath = "nome";
            CmbEspecialista.ItemsSource = dt.DefaultView;

            conn.Close();

            TxtDataInicio.IsEnabled = false;
            TxtDataTermino.IsEnabled = false;
            TxtNomeCompleto.IsEnabled = false;
            TxtEndereco.IsEnabled = false;
            TxtNumero.IsEnabled = false;
            TxtComplemento.IsEnabled = false;
            TxtBairro.IsEnabled = false;
            TxtCidade.IsEnabled = false;
            TxtUf.IsEnabled = false;
            TxtCep.IsEnabled = false;
            TxtTelefone.IsEnabled = false;
            TxtCelular.IsEnabled = false;
            TxtEmail.IsEnabled = false;
            TxtEspecialidade.IsEnabled = false;
            ChkSegunda.IsEnabled = false;
            ChkTerca.IsEnabled = false;
            ChkQuarta.IsEnabled = false;
            ChkQuinta.IsEnabled = false;
            ChkSexta.IsEnabled = false;
            ChkSabado.IsEnabled = false;

            BtnAlterar.IsEnabled = true;
            BtnExcluir.IsEnabled = false;
            BtnSalvar.IsEnabled = false;

            TxtDataInicio.Text = "";
            TxtDataTermino.Text = "";
            TxtNomeCompleto.Text = "";
            TxtEndereco.Text = "";
            TxtNumero.Text = "";
            TxtComplemento.Text = "";
            TxtBairro.Text = "";
            TxtCidade.Text = "";
            TxtUf.Text = "";
            TxtCep.Text = "";
            TxtTelefone.Text = "";
            TxtCelular.Text = "";
            TxtEmail.Text = "";
            TxtEspecialidade.Text = "";
            ChkSegunda.IsEnabled = false;
            ChkTerca.IsEnabled = false;
            ChkQuarta.IsEnabled = false;
            ChkQuinta.IsEnabled = false;
            ChkSexta.IsEnabled = false;
            ChkSabado.IsEnabled = false;

            BtnAlterar.IsEnabled = true;
            BtnExcluir.IsEnabled = false;
            BtnSalvar.IsEnabled = false;
        }

        private void BtnAlterar_Click(object sender, RoutedEventArgs e)
        {
            TxtDataInicio.IsEnabled = true;
            TxtDataTermino.IsEnabled = true;
            TxtNomeCompleto.IsEnabled = true;
            TxtEndereco.IsEnabled = true;
            TxtNumero.IsEnabled = true;
            TxtComplemento.IsEnabled = true;
            TxtBairro.IsEnabled = true;
            TxtCidade.IsEnabled = true;
            TxtUf.IsEnabled = true;
            TxtCep.IsEnabled = true;
            TxtTelefone.IsEnabled = true;
            TxtCelular.IsEnabled = true;
            TxtEmail.IsEnabled = true;
            TxtEspecialidade.IsEnabled = true;
            ChkSegunda.IsEnabled = true;
            ChkTerca.IsEnabled = true;
            ChkQuarta.IsEnabled = true;
            ChkQuinta.IsEnabled = true;
            ChkSexta.IsEnabled = true;
            ChkSabado.IsEnabled = true;

            BtnAlterar.IsEnabled = false;
            BtnExcluir.IsEnabled = true;
            BtnSalvar.IsEnabled = true;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            MySqlConnection cn = new MySqlConnection();
            cn.ConnectionString = "SERVER=localhost;USER=root;DATABASE=kibeleza";
            cn.Open();

            string selecionar = "SELECT * FROM especialista";

            MySqlCommand com = new MySqlCommand(selecionar, cn);

            MySqlDataAdapter da = new MySqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            CmbEspecialista.DisplayMemberPath = "nome";
            CmbEspecialista.ItemsSource = dt.DefaultView;
        }

        private void CmbEspecialista_KeyDown(object sender, KeyEventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("SERVER=localhost;USER=root;DATABASE=kibeleza");
            conn.Open();
            MySqlCommand comm = new MySqlCommand("SELECT * FROM especialista " + "HERE nome = ?", conn);
            comm.Parameters.Clear();
            comm.Parameters.Add("@nome", MySqlDbType.String).Value = CmbEspecialista.Text;
            /*Aqui no commandType tem que definir se vai utilizar uma Stored Procedure

            comm.CommandType = CommandType.Text; /*executao comando*/
            //recebe conteúdo do banco
            MySqlDataReader dr = comm.ExecuteReader();
            dr.Read();

            TxtCodigo.Text = dr.GetString(0);
            TxtDataInicio.Text = dr.GetString(1);
            TxtDataTermino.Text = dr.GetString(2);
            TxtNomeCompleto.Text = dr.GetString(3);
            TxtEndereco.Text = dr.GetString(4);
            TxtNumero.Text = dr.GetString(5);
            TxtComplemento.Text = dr.GetString(6);
            TxtBairro.Text = dr.GetString(7);
            TxtCidade.Text = dr.GetString(8);
            TxtUf.Text = dr.GetString(9);
            TxtCep.Text = dr.GetString(10);
            TxtTelefone.Text = dr.GetString(11);
            TxtCelular.Text = dr.GetString(12);
            TxtEmail.Text = dr.GetString(13);
            TxtEspecialidade.Text = dr.GetString(14);

            if (Regex.IsMatch(dr.GetString(15), "Segunda-feira", RegexOptions.Multiline))
            {
                ChkSegunda.IsChecked = true;
            }
            else
            {
                ChkSegunda.IsChecked = false;
            }

            if (Regex.IsMatch(dr.GetString(15), "Terça-feira", RegexOptions.Multiline))
            {
                ChkTerca.IsChecked = true;
            }
            else
            {
                ChkTerca.IsChecked = false;
            }

            if (Regex.IsMatch(dr.GetString(15), "Quarta-feira", RegexOptions.Multiline))
            {
                ChkQuarta.IsChecked = true;
            }
            else
            {
                ChkQuarta.IsChecked = false;
            }

            if (Regex.IsMatch(dr.GetString(15), "Quinta-feira", RegexOptions.Multiline))
            {
                ChkQuinta.IsChecked = true;
            }
            else
            {
                ChkQuinta.IsChecked = false;
            }

            if (Regex.IsMatch(dr.GetString(15), "Sexta-feira", RegexOptions.Multiline))
            {
                ChkSexta.IsChecked = true;
            }
            else
            {
                ChkSexta.IsChecked = false;
            }

            if (Regex.IsMatch(dr.GetString(15), "Sabado", RegexOptions.Multiline))
            {
                ChkSabado.IsChecked = true;
            }
            else
            {
                ChkSabado.IsChecked = false;
            }

        }

        private void BtnSalvar_Click(object sender, RoutedEventArgs e)
        {
            codigo = int.Parse(TxtCodigo.Text);
            dataInicio = TxtDataInicio.Text;
            dataTermino = TxtDataTermino.Text;
            nome = TxtNomeCompleto.Text;
            endereco = TxtEndereco.Text;
            numero = int.Parse(TxtNumero.Text);
            complemento = TxtComplemento.Text;
            bairro = TxtBairro.Text;
            cidade = TxtCidade.Text;
            uf = TxtUf.Text;
            cep = TxtCep.Text;
            telefone = TxtTelefone.Text;
            celular = TxtCelular.Text;
            email = TxtEmail.Text;
            especialidade = TxtEspecialidade.Text;

            MySqlConnection conn = new MySqlConnection("SERVER=localhost;USER=root;DATABASE=kibeleza");
            conn.Open();
            MySqlCommand comm = new MySqlCommand("UPDATE especialista set datainicio = ?, " +
                "datatermino = ?, nome = ?, endereco = ?, numero = ?, complemento = ?, " +
                "bairro = ?, cidade = ?, uf = ?, cep = ?, telefone = ?, celular = ?, " +
                "email = ?, especialidade = ?, diasdasemana = ?, WHERE codigo = ?", conn);
            comm.Parameters.Clear();

            comm.Parameters.Add("@datainicio", MySqlDbType.String).Value = dataInicio;
            comm.Parameters.Add("@datatermino", MySqlDbType.String).Value = dataTermino;
            comm.Parameters.Add("@nome", MySqlDbType.String).Value = nome;
            comm.Parameters.Add("@endereco", MySqlDbType.String).Value = endereco;
            comm.Parameters.Add("@numero", MySqlDbType.String).Value = numero;
            comm.Parameters.Add("@complemento", MySqlDbType.String).Value = complemento;
            comm.Parameters.Add("@bairro", MySqlDbType.String).Value = bairro;
            comm.Parameters.Add("@cidade", MySqlDbType.String).Value = cidade;
            comm.Parameters.Add("@uf", MySqlDbType.String).Value = uf;
            comm.Parameters.Add("@cep", MySqlDbType.String).Value = cep;
            comm.Parameters.Add("@telefone", MySqlDbType.String).Value = telefone;
            comm.Parameters.Add("@celular", MySqlDbType.String).Value = celular;
            comm.Parameters.Add("@email", MySqlDbType.String).Value = email;
            comm.Parameters.Add("@especialidade", MySqlDbType.String).Value = especialidade;
            comm.Parameters.Add("@diasdasemana", MySqlDbType.String).Value = diasdasemana;
            comm.Parameters.Add("@codigo", MySqlDbType.String).Value = codigo;

            comm.CommandType = CommandType.Text; /*executa o comando*/
            comm.ExecuteNonQuery();

            MessageBox.Show("Alteração realizada com sucesso!");

            string selecionar = "SELECT * FROM especialista";

            MySqlCommand com = new MySqlCommand(selecionar, conn);

            MySqlDataAdapter da = new MySqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            CmbEspecialista.DisplayMemberPath = "nome";
            CmbEspecialista.ItemsSource = dt.DefaultView;

            conn.Close();

            TxtDataInicio.IsEnabled = false;
            TxtDataTermino.IsEnabled = false;
            TxtNomeCompleto.IsEnabled = false;
            TxtEndereco.IsEnabled = false;
            TxtNumero.IsEnabled = false;
            TxtComplemento.IsEnabled = false;
            TxtBairro.IsEnabled = false;
            TxtCidade.IsEnabled = false;
            TxtUf.IsEnabled = false;
            TxtCep.IsEnabled = false;
            TxtTelefone.IsEnabled = false;
            TxtCelular.IsEnabled = false;
            TxtEmail.IsEnabled = false;
            TxtEspecialidade.IsEnabled = false;
            ChkSegunda.IsEnabled = false;
            ChkTerca.IsEnabled = false;
            ChkQuarta.IsEnabled = false;
            ChkQuinta.IsEnabled = false;
            ChkSexta.IsEnabled = false;
            ChkSabado.IsEnabled = false;

            BtnAlterar.IsEnabled = true;
            BtnExcluir.IsEnabled = false;
            BtnSalvar.IsEnabled = false;
        }

        private void ChkSegunda_Checked(object sender, RoutedEventArgs e)
        {
            segunda = ChkSegunda.ToString();
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void ChkSegunda_Unchecked(object sender, RoutedEventArgs e)
        {
            segunda = null;
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void ChkTerca_Checked(object sender, RoutedEventArgs e)
        {
            terca = ChkSegunda.ToString();
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void ChkTerca_Unchecked(object sender, RoutedEventArgs e)
        {
            terca = null;
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void ChkQuarta_Checked(object sender, RoutedEventArgs e)
        {
            quarta = ChkSegunda.ToString();
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void ChkQuarta_Unchecked(object sender, RoutedEventArgs e)
        {
            quarta = null;
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void ChkQuinta_Checked(object sender, RoutedEventArgs e)
        {
            quinta = ChkSegunda.ToString();
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void ChkQuinta_Unchecked(object sender, RoutedEventArgs e)
        {
            quinta = null;
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void ChkSexta_Checked(object sender, RoutedEventArgs e)
        {
            sexta = ChkSegunda.ToString();
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void ChkSexta_Unchecked(object sender, RoutedEventArgs e)
        {
            sexta = null;
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void ChkSabado_Checked(object sender, RoutedEventArgs e)
        {
            sabado = ChkSegunda.ToString();
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }
    }
}
