﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaKiBeleza
{
    /// <summary>
    /// Lógica interna para FrmMenu.xaml
    /// </summary>
    public partial class FrmMenu : Window
    {
        public FrmMenu()
        {
            InitializeComponent();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            FrmCadClientes frm = new FrmCadClientes();
            frm.Show();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow frm = new MainWindow();
            frm.Show();
            this.Close();
        }

        private void BtnCadProdutos_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            FrmCadProduto frm = new FrmCadProduto();
            frm.Show();
        }

        private void BtnCadFuncionarios_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            FrmCadFuncionarios frm = new FrmCadFuncionarios();
            frm.Show();
        }

        private void BtnCadEspecialistas_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            FrmCadEspecialistas frm = new FrmCadEspecialistas();
            frm.Show();
        }

        private void BtnCadFornecedores_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            FrmCadFornecedores frm = new FrmCadFornecedores();
            frm.Show();
        }

        private void BtnCadEspecialidades_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            FrmCadEspecialidades frm = new FrmCadEspecialidades();
            frm.Show();
        }

        private void BtnEncerrar_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void BtnAgenda_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            FrmCadastroAgenda frm = new FrmCadastroAgenda();
            frm.Show();
        }
    }
}
