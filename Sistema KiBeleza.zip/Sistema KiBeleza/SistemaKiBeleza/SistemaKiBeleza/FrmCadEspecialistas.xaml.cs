﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaKiBeleza
{
    /// <summary>
    /// Lógica interna para FrmCadEspecialistas.xaml
    /// </summary>
    public partial class FrmCadEspecialistas : Window
    {
        string nome, endereco, bairro, cidade, uf, email, especialidade, dataInicio, dataTermino, complemento, cep, telefone, celular, diasemana, diadasemana, segunda, terca, quarta, quinta, sexta, sabado;
        int numero;

        private void TxtEndereco_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtEndereco.Text != "")
                {
                    endereco = TxtEndereco.Text; //Variável nome recebe o conteúdo da caixa de texto
                    LblEndereco.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtNumero.IsEnabled = true;
                    TxtNumero.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblEndereco.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtNumero_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtNumero.Text != "")
                {
                    numero = int.Parse(TxtNumero.Text); //Variável nome recebe o conteúdo da caixa de texto
                    LblNumero.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtComplemento.IsEnabled = true;
                    TxtComplemento.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblNumero.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void ChkSegunda_Checked(object sender, RoutedEventArgs e)
        {
            segunda = ChkSegunda.ToString();
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void ChkSegunda_Unchecked(object sender, RoutedEventArgs e)
        {
            segunda = null;
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void ChkTerca_Checked(object sender, RoutedEventArgs e)
        {
            terca = ChkSegunda.ToString();
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void ChkTerca_Unchecked(object sender, RoutedEventArgs e)
        {
            terca = null;
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void ChkQuarta_Checked(object sender, RoutedEventArgs e)
        {
            quarta = ChkSegunda.ToString();
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void ChkQuarta_Unchecked(object sender, RoutedEventArgs e)
        {
            quarta = null;
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void ChkQuinta_Checked(object sender, RoutedEventArgs e)
        {
            quinta = ChkSegunda.ToString();
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void ChkQuinta_Unchecked(object sender, RoutedEventArgs e)
        {
            quinta = null;
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void ChkSexta_Checked(object sender, RoutedEventArgs e)
        {
            sexta = ChkSegunda.ToString();
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void ChkSexta_Unchecked(object sender, RoutedEventArgs e)
        {
            sexta = null;
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void ChkSabado_Checked(object sender, RoutedEventArgs e)
        {
            sabado = ChkSegunda.ToString();
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void FrmCadEspecialista_Loaded(object sender, RoutedEventArgs e)
        {
            MySqlConnection cn = new MySqlConnection();
            cn.ConnectionString = "SERVER=localhost;USER=root;DATABASE=kibeleza";
            cn.Open();

            string selecionar = "SELECT especialidade FROM especialidade";

            MySqlCommand com = new MySqlCommand(selecionar, cn);

            MySqlDataAdapter da = new MySqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            CmbEspecialidade.DisplayMemberPath = "especialidade";
            CmbEspecialidade.ItemsSource = dt.DefaultView;
        }

        private void BtnExcluir_Click(object sender, RoutedEventArgs e)
        {

        }

        private void CmbEspecialidade_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (CmbEspecialidade.Text != "")
                {
                    especialidade = CmbEspecialidade.Text;
                    ChkSegunda.IsEnabled = true;
                    ChkTerca.IsEnabled = true;
                    ChkQuarta.IsEnabled = true;
                    ChkQuinta.IsEnabled = true;
                    ChkSexta.IsEnabled = true;
                    ChkSabado.IsEnabled = true;
                    BtnSalvar.IsEnabled = true;
                    ChkSegunda.Focus();
                }
                else
                {
                    MessageBox.Show("Favor selecionar a especialidade!");
                    LblEspecialidade.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void ChkSabado_Unchecked(object sender, RoutedEventArgs e)
        {
            sabado = null;
            diasemana = segunda + ", " + terca + ", " + quarta + ", " + quinta + ", " + sexta + ", " + sabado + ", ";
        }

        private void TxtComplemento_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtComplemento.Text != "")
                {
                    complemento = (TxtComplemento.Text); //Variável nome recebe o conteúdo da caixa de texto
                    LblComplemento.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtBairro.IsEnabled = true;
                    TxtBairro.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblComplemento.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtBairro_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtBairro.Text != "")
                {
                    bairro = TxtBairro.Text; //Variável nome recebe o conteúdo da caixa de texto
                    LblBairro.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtCidade.IsEnabled = true;
                    TxtCidade.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblBairro.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtCidade_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtCidade.Text != "")
                {
                    cidade = TxtCidade.Text; //Variável nome recebe o conteúdo da caixa de texto
                    LblCidade.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    CmbUf.IsEnabled = true;
                    CmbUf.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblCidade.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void CmbUf_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (CmbUf.Text != "")
                {
                    uf = CmbUf.Text; //Variável nome recebe o conteúdo da caixa de texto
                    LblUf.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtCep.IsEnabled = true;
                    TxtCep.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblUf.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void BtnLimpar_Click(object sender, RoutedEventArgs e)
        {
            TxtDataInicio.Text = "";
            TxtDataTermino.Text = "";
            TxtNomeCompleto.Text = "";
            TxtEndereco.Text = "";
            TxtNumero.Text = "";
            TxtComplemento.Text = "";
            TxtBairro.Text = "";
            TxtCidade.Text = "";
            CmbUf.Text = "";
            TxtCep.Text = "";
            TxtTelefone.Text = "";
            TxtCelular.Text = "";
            TxtEmail.Text = "";
            CmbEspecialidade.Text = "";
            ChkSegunda.IsEnabled = false;
            ChkTerca.IsEnabled = false;
            ChkQuarta.IsEnabled = false;
            ChkQuinta.IsEnabled = false;
            ChkSexta.IsEnabled = false;
            ChkSabado.IsEnabled = false;

            BtnSalvar.IsEnabled = false;
            BtnLimpar.IsEnabled = false;
            BtnNovo.IsEnabled = true;
            BtnNovo.Focus();

            TxtDataInicio.IsEnabled = false;
            TxtDataTermino.IsEnabled = false;
            TxtNomeCompleto.IsEnabled = false;
            TxtEndereco.IsEnabled = false;
            TxtNumero.IsEnabled = false;
            TxtComplemento.IsEnabled = false;
            TxtBairro.IsEnabled = false;
            TxtCidade.IsEnabled = false;
            CmbUf.IsEnabled = false;
            TxtCep.IsEnabled = false;
            TxtTelefone.IsEnabled = false;
            TxtCelular.IsEnabled = false;
            TxtEmail.IsEnabled = false;
            CmbEspecialidade.IsEnabled = false;

            dataInicio = null;
            dataTermino = null;
            nome = null;
            endereco = null;
            numero = 0;
            complemento = null;
            bairro = null;
            cidade = null;
            uf = null;
            cep = null;
            telefone = null;
            celular = null;
            email = null;
            especialidade = null;

            
        }

        private void BtnSalvar_Click(object sender, RoutedEventArgs e)
        {
            modelos mo = new modelos();
            cone db = new cone();

            mo.DataInicio = dataInicio;
            mo.DataTermino = dataTermino;
            mo.Nome = nome;
            mo.Endereco = endereco;
            mo.Numero = numero;
            mo.Complemento = complemento;
            mo.Bairro = bairro;
            mo.Cidade = cidade;
            mo.Uf = uf;
            mo.Cep = cep;
            mo.Telefone1 = telefone;
            mo.Celular1 = celular;
            mo.Email = email;
            mo.Especialidade = especialidade;
            mo.DiaSemana = diadasemana;

            db.cadespecialista(mo);

            MessageBox.Show("Especialista cadastrador com sucesso!");

            TxtDataInicio.Text = "";
            TxtDataTermino.Text = "";
            TxtNomeCompleto.Text = "";
            TxtEndereco.Text = "";
            TxtNumero.Text = "";
            TxtComplemento.Text = "";
            TxtBairro.Text = "";
            TxtCidade.Text = "";
            CmbUf.Text = "";
            TxtCep.Text = "";
            TxtTelefone.Text = "";
            TxtCelular.Text = "";
            TxtEmail.Text = "";
            CmbEspecialidade.Text = "";
            ChkSegunda.IsEnabled = false;
            ChkTerca.IsEnabled = false;
            ChkQuarta.IsEnabled = false;
            ChkQuinta.IsEnabled = false;
            ChkSexta.IsEnabled = false;
            ChkSabado.IsEnabled = false;

            BtnSalvar.IsEnabled = false;
            BtnLimpar.IsEnabled = false;
            BtnNovo.IsEnabled = true;
            BtnNovo.Focus();

            TxtDataInicio.IsEnabled = false;
            TxtDataTermino.IsEnabled = false;
            TxtNomeCompleto.IsEnabled = false;
            TxtEndereco.IsEnabled = false;
            TxtNumero.IsEnabled = false;
            TxtComplemento.IsEnabled = false;
            TxtBairro.IsEnabled = false;
            TxtCidade.IsEnabled = false;
            CmbUf.IsEnabled = false;
            TxtCep.IsEnabled = false;
            TxtTelefone.IsEnabled = false;
            TxtCelular.IsEnabled = false;
            TxtEmail.IsEnabled = false;
            CmbEspecialidade.IsEnabled = false;
        }

        

        private void TxtCep_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtCep.Text != "")
                {
                    cep = (TxtCep.Text); //Variável nome recebe o conteúdo da caixa de texto
                    LblCep.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtTelefone.IsEnabled = true;
                    TxtTelefone.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblCep.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtTelefone_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtTelefone.Text != "")
                {
                    telefone = (TxtTelefone.Text); //Variável nome recebe o conteúdo da caixa de texto
                    LblTelefone.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtCelular.IsEnabled = true;
                    TxtCelular.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblTelefone.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtCelular_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtCelular.Text != "")
                {
                    celular = (TxtCelular.Text); //Variável nome recebe o conteúdo da caixa de texto
                    LblCelular.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtEmail.IsEnabled = true;
                    TxtEmail.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblCelular.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtEmail_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtEmail.Text != "")
                {
                    email = TxtEmail.Text; //Variável nome recebe o conteúdo da caixa de texto
                    LblEmail.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    CmbEspecialidade.IsEnabled = true;
                    CmbEspecialidade.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblEmail.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtEspecialidade_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void TxtNomeCompleto_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void BtnNovo_Click(object sender, RoutedEventArgs e)
        {
            TxtDataInicio.IsEnabled = true;
            TxtDataInicio.Focus();
            TxtDataInicio.Text = DateTime.Now.ToShortDateString();

            BtnNovo.IsEnabled = false;
            BtnLimpar.IsEnabled = true;
        }

        private void TxtNomeCompleto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtNomeCompleto.Text != "")
                {
                    nome = TxtNomeCompleto.Text; //Variável nome recebe o conteúdo da caixa de texto
                    LblNomeCompleto.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtEndereco.IsEnabled = true;
                    TxtEndereco.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblNomeCompleto.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtDataTermino_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtDataTermino.Text != "")
                {
                    dataTermino = (TxtDataTermino.Text); //Variável nome recebe o conteúdo da caixa de texto
                    LblDataTermino.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtNomeCompleto.IsEnabled = true;
                    TxtNomeCompleto.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblDataTermino.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        public FrmCadEspecialistas()
        {
            InitializeComponent();
        }

        private void BtnSair_Click(object sender, RoutedEventArgs e)
        {
            FrmMenu frm = new FrmMenu();
            frm.Show();
            this.Close();
        }

        private void TxtDataInicio_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtDataInicio.Text != "")
                {
                    dataInicio = (TxtDataInicio.Text); //Variável nome recebe o conteúdo da caixa de texto
                    LblDataInicio.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtDataTermino.IsEnabled = true;
                    TxtDataTermino.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblDataInicio.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
    }
}
