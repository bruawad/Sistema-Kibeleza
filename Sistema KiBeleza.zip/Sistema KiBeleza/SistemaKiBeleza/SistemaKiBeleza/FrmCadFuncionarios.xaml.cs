﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaKiBeleza
{
    /// <summary>
    /// Lógica interna para FrmCadFuncionarios.xaml
    /// </summary>
    public partial class FrmCadFuncionarios : Window
    {
        string nome, endereco, bairro, cidade, uf, email, cargo, dataAdmissao, complemento, cep, telefone, celular, dataDemissao;
        int numero, codigo;

        private void TxtNumero_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtNumero.Text != "")
                {
                    numero = int.Parse(TxtNumero.Text); //Variável nome recebe o conteúdo da caixa de texto
                    LblNumero.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtComplemento.IsEnabled = true;
                    TxtComplemento.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblNumero.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtComplemento_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtComplemento.Text != "")
                {
                    complemento = (TxtComplemento.Text); //Variável nome recebe o conteúdo da caixa de texto
                    LblComplemento.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtBairro.IsEnabled = true;
                    TxtBairro.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblComplemento.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtBairro_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtBairro.Text != "")
                {
                    bairro = TxtBairro.Text; //Variável nome recebe o conteúdo da caixa de texto
                    LblBairro.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtCidade.IsEnabled = true;
                    TxtCidade.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblBairro.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtCidade_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtCidade.Text != "")
                {
                    cidade = TxtCidade.Text; //Variável nome recebe o conteúdo da caixa de texto
                    LblCidade.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    CmbUf.IsEnabled = true;
                    CmbUf.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblCidade.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void CmbUf_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (CmbUf.Text != "")
                {
                    uf = CmbUf.Text; //Variável nome recebe o conteúdo da caixa de texto
                    LblUF.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtCEP.IsEnabled = true;
                    TxtCEP.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblUF.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void BtnSalvar_Click(object sender, RoutedEventArgs e)
        {
            modelos mo = new modelos();
            cone db = new cone();

            mo.DataAdmissao = dataAdmissao;
            mo.Nome = nome;
            mo.Endereco = endereco;
            mo.Numero = numero;
            mo.Complemento = complemento;
            mo.Bairro = bairro;
            mo.Cidade = cidade;
            mo.Uf = uf;
            mo.Cep = cep;
            mo.Telefone1 = telefone;
            mo.Celular1 = celular;
            mo.Email = email;
            mo.Cargo = cargo;
            mo.DataDemissao = dataDemissao;

            db.cadfuncionarios(mo);

            MessageBox.Show("Especialista cadastrador com sucesso!");

            TxtDatadeAdmissao.Text = "";
            TxtNomeCompleto.Text = "";
            TxtEndereco.Text = "";
            TxtNumero.Text = "";
            TxtComplemento.Text = "";
            TxtBairro.Text = "";
            TxtCidade.Text = "";
            CmbUf.Text = "";
            TxtCEP.Text = "";
            TxtTelefone.Text = "";
            TxtCelular.Text = "";
            TxtEmail.Text = "";
            TxtCargo.Text = "";
            TxtDatadeDemissao.Text = "";

            BtnSalvar.IsEnabled = false;
            BtnLimpar.IsEnabled = false;
            BtnNovo.IsEnabled = true;
            BtnNovo.Focus();

            TxtDatadeAdmissao.IsEnabled = false;
            TxtNomeCompleto.IsEnabled = false;
            TxtEndereco.IsEnabled = false;
            TxtNumero.IsEnabled = false;
            TxtComplemento.IsEnabled = false;
            TxtBairro.IsEnabled = false;
            TxtCidade.IsEnabled = false;
            CmbUf.IsEnabled = false;
            TxtCEP.IsEnabled = false;
            TxtTelefone.IsEnabled = false;
            TxtCelular.IsEnabled = false;
            TxtEmail.IsEnabled = false;
            TxtCargo.IsEnabled = false;
            TxtDatadeDemissao.IsEnabled = false;
        }

        private void TxtCEP_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtCEP.Text != "")
                {
                    cep = (TxtCEP.Text); //Variável nome recebe o conteúdo da caixa de texto
                    LblCEP.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtTelefone.IsEnabled = true;
                    TxtTelefone.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblCEP.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtTelefone_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtTelefone.Text != "")
                {
                    telefone = (TxtTelefone.Text); //Variável nome recebe o conteúdo da caixa de texto
                    LblTelefone.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtCelular.IsEnabled = true;
                    TxtCelular.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblTelefone.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtCelular_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtCelular.Text != "")
                {
                    celular = (TxtCelular.Text); //Variável nome recebe o conteúdo da caixa de texto
                    LblCelular.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtEmail.IsEnabled = true;
                    TxtEmail.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblCelular.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtEmail_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtEmail.Text != "")
                {
                    email = TxtEmail.Text; //Variável nome recebe o conteúdo da caixa de texto
                    LblEmail.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtCargo.IsEnabled = true;
                    TxtCargo.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblEmail.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtCargo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtCargo.Text != "")
                {
                    cargo = TxtCargo.Text; //Variável nome recebe o conteúdo da caixa de texto
                    LblCargo.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtDatadeDemissao.IsEnabled = true;
                    TxtDatadeDemissao.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblCargo.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtDatadeDemissao_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtDatadeDemissao.Text != "")
                {
                    dataDemissao = (TxtDatadeDemissao.Text); //Variável nome recebe o conteúdo da caixa de texto
                    LblDatadeDemissao.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    BtnSalvar.IsEnabled = true;
                    BtnSalvar.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblDatadeDemissao.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void BtnNovo_Click(object sender, RoutedEventArgs e)
        {
            TxtDatadeAdmissao.IsEnabled = true;
            TxtDatadeAdmissao.Focus();
            TxtDatadeAdmissao.Text = DateTime.Now.ToShortDateString();

            BtnNovo.IsEnabled = false;
            BtnLimpar.IsEnabled = true;
        }

        private void BtnLimpar_Click(object sender, RoutedEventArgs e)
        {
            TxtDatadeAdmissao.Text = "";
            TxtNomeCompleto.Text = "";
            TxtEndereco.Text = "";
            TxtNumero.Text = "";
            TxtComplemento.Text = "";
            TxtBairro.Text = "";
            TxtCidade.Text = "";
            CmbUf.Text = "";
            TxtCEP.Text = "";
            TxtTelefone.Text = "";
            TxtCelular.Text = "";
            TxtEmail.Text = "";
            TxtCargo.Text = "";
            TxtDatadeDemissao.Text = "";

            TxtDatadeAdmissao.IsEnabled = false;
            TxtNomeCompleto.IsEnabled = false;
            TxtEndereco.IsEnabled = false;
            TxtNumero.IsEnabled = false;
            TxtComplemento.IsEnabled = false;
            TxtBairro.IsEnabled = false;
            TxtCidade.IsEnabled = false;
            CmbUf.IsEnabled = false;
            TxtCEP.IsEnabled = false;
            TxtTelefone.IsEnabled = false;
            TxtCelular.IsEnabled = false;
            TxtEmail.IsEnabled = false;
            TxtCargo.IsEnabled = false;
            TxtDatadeDemissao.IsEnabled = false;

            dataAdmissao = null;
            nome = null;
            endereco = null;
            numero = 0;
            complemento = null;
            bairro = null;
            cidade = null;
            uf = null;
            cep = null;
            telefone = null;
            celular = null;
            email = null;
            cargo = null;
            dataDemissao = null;

            BtnSalvar.IsEnabled = false;
            BtnLimpar.IsEnabled = false;
            BtnNovo.IsEnabled = true;
            BtnNovo.Focus();
        }

        private void TxtEndereco_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtEndereco.Text != "")
                {
                    endereco = TxtEndereco.Text; //Variável nome recebe o conteúdo da caixa de texto
                    LblEndereco.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtNumero.IsEnabled = true;
                    TxtNumero.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblEndereco.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtNomeCompleto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtNomeCompleto.Text != "")
                {
                    nome = TxtNomeCompleto.Text; //Variável nome recebe o conteúdo da caixa de texto
                    LblNomeCompleto.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtEndereco.IsEnabled = true;
                    TxtEndereco.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblNomeCompleto.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        
        public FrmCadFuncionarios()
        {
            InitializeComponent();
        }

        private void BtnSair_Click(object sender, RoutedEventArgs e)
        {
            FrmMenu frm = new FrmMenu();
            frm.Show();
            this.Close();
        }

        private void TxtDatadeAdmissao_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtDatadeAdmissao.Text != "")
                {
                    dataAdmissao = (TxtDatadeAdmissao.Text); //Variável nome recebe o conteúdo da caixa de texto
                    LblDatadeAdmissao.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtNomeCompleto.IsEnabled = true;
                    TxtNomeCompleto.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblDatadeAdmissao.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
    }
}
